from distutils.core import setup

setup(name='miniDust',
      version='1.0',
      py_modules=['test']
      )